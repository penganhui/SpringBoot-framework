本项目主要用于我最近写的几篇 《Flink 入门》系列文章的示例工程代码。并不是直接生产可用的代码。

如果你对《Flink 入门》系列比较感兴趣，欢迎关注我的博客：http://wuchong.me/tags/Flink入门/

也可以关注我的个人微信公众号：

<img src="https://img.alicdn.com/tfs/TB1.ajIlIbpK1RjSZFyXXX_qFXa-1004-541.png" width="500px" />


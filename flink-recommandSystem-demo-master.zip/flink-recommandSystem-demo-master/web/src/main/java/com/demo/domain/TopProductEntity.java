package com.demo.domain;

/**
 * @author XINZE
 */
public class TopProductEntity {

    private int productId;
    private int actionTimes;

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getActionTimes() {
        return actionTimes;
    }

    public void setActionTimes(int actionTimes) {
        this.actionTimes = actionTimes;
    }
}

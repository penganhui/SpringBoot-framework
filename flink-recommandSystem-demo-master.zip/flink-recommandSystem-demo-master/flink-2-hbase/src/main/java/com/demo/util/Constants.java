package com.demo.util;

public class Constants {

    public static final String SEX_MAN = "1";
    public static final String SEX_WOMAN = "0";
    public static final String AGE_10 = "10s";
    public static final String AGE_20 = "20s";
    public static final String AGE_30 = "30s";
    public static final String AGE_40 = "40s";
    public static final String AGE_50 = "50s";
    public static final String AGE_60 = "50s";

}

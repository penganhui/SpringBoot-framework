package com.calabar.flinkDemo.hbase.loader;

public interface ILoader {

    void loader() throws Exception;
}

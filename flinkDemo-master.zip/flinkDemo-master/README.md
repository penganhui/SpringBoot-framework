# flinkDemo
# 有关flink使用的基础demo
## 代码包括
### world count
### stream
### kafka发送接收
### hbase存储
